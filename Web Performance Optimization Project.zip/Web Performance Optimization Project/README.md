The goal was to optimize a given website so that each page reaches a page speed of at least 90 measured with Page Speed Insights.


*Open and unzip the file Web Performance Optimization Project
*Launch index.html

Original Page Speed (of 100)
(the numbers can vary slightly dependent on the network connection)

*Desktop / Mobile
*index.html = 90


##Optimizations made in main.js for pizza.html

** Replaced querySelectorAll with getElementsByClassName for better performance
** "document.body.scrollTop / 1250" is moved outside the for loop
** Reduced the amount of animated pizzas from 200 to 40
** moved calculation of "dx" and "newwidth" outside the for loop in function "changePizzaSizes" and assigned all the elements from "document.getElementsByClassName("randomPizzaContainer")"" to a variable "randomPizzaContainer"
** replaced "querySelector(..)" with "getElementById(..)"


## More information for website optimization
##Website Performance Optimization portfolio project

Your challenge, if you wish to accept it (and we sure hope you will), is to optimize this online portfolio for speed! In particular, optimize the critical rendering path and make this page render as quickly as possible by applying the techniques you've picked up in the Critical Rendering Path course.


Getting started

## Part 1: Optimize PageSpeed Insights score for index.html

Some useful tips to help you get started:

1. Open a browser and visit localhost:8145
2. Download and install [ngrok](https://ngrok.com/) to make your local server accessible remotely.
  
  ** Make you server work on port 8145
     python -m http.server 8145

  ** On ngrok
     ngrok http localhost:8145
     Copy the public URL ngrok gives you and try running it through PageSpeed Insights!

## Part 2: Optimize Frames per Second in pizza.html
To optimize views/pizza.html, you will need to modify views/js/main.js until your frames per second rate is 60 fps or higher. You will find instructive comments in main.js.

## Part 3: Make the time to resize pizzas less than 5 ms using the pizza size slider on the views/pizza.html page. Resize time is shown in the browser developer tools.

## Tools used:

python-3.6.2
ngrok
jscompress.com/
cssminifier.com/
minifycode.com/html-minifier/
optimizilla.com
PageSpeed Insights

